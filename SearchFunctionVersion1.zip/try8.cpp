# include <stdio.h>
# include <vector>
# include <sstream>
# include <stdlib.h>
# include <string.h>
# include <string>
# include <ctype.h>
# include <algorithm>
# include <queue>
# include <iostream>

using namespace std;

typedef pair<int, int> ii;

int tot, weight;
vector<string> list[500];
int score[500];

int notsame(char a, char b)
{
	if (tolower(a) == tolower(b)) return 0;

	return 1;
}

int edit(string a, string b)
{
	int f[200][200];
	int lena = a.length();
	int lenb = b.length();

	memset(f, 0, sizeof(f));

	for (int i = 1; i <= lena; i++)
	{
		f[i][0] = i;
	}

	for (int i = 1; i <= lenb; i++)
	{
		f[0][i] = i;
	}

	for (int i = 1; i <= lena; i++)
		for (int j = 1; j <= lenb; j++)
		{
			f[i][j] = min(min(f[i - 1][j] + 1, f[i][j - 1] + 1), f[i - 1][j - 1] + notsame(a[i - 1], b[j - 1]));
		}

	return f[lena][lenb];
}

int sqr(int x)
{
	return x * x;
}

int calWeight(int i, int tot)
{
	return sqr(tot - i);
}

int main()
{
	freopen("lists.txt", "r", stdin);

	tot = 0;

	string line;

	while (getline(cin, line, '\n'))
	{
		stringstream sin(line);
		string s;

		while (sin>>s)
		{
			list[tot].push_back(s);
		}

		tot++;
	}

	int key = --tot;

	printf("Searching for : ");

	for (int i = 0; i < (int)list[key].size(); i++)
	{
		printf("%s ", list[key][i].c_str());
	}

	printf("\n\n");

	for (int i = 0; i < (int)list[key].size(); i++)
	{
		string curKey = list[key][i];
		priority_queue<ii> pq;

		weight = calWeight(i, list[key].size());

		for (int j = 0; j < tot; j++)
		{
			int tempScore = -1000;
			
			for (int k = 0; k < (int)list[j].size(); k++)
			{
				string curP = list[j][k];
				int curScore = edit(curKey, curP);

				tempScore = max(tempScore, -curScore);
			}

			pq.push(ii(tempScore, j));
		}

		int point = pq.size();
		int share = 1;

		while (!pq.empty())
		{
			int tScore = pq.top().first;
			
			score[pq.top().second] += point * weight;
			pq.pop();

			if (!pq.empty() && pq.top().first == tScore)
			{
				share++;
			} else
			{
				point -= share;
				share = 1;
			}
		}
	}

	vector<ii> v;

	for (int i = 0; i < tot; i++)
	{
		v.push_back(ii(score[i], i));
	}

	sort(v.rbegin(), v.rend());

	for (int i = 0; i < tot; i++)
	{
		int curRecord = v[i].second;

		printf("%d.\tscore = %d\t", i + 1, score[curRecord]);
		
		for (int j = 0; j < (int)list[curRecord].size(); j++)
			printf("%s ", list[curRecord][j].c_str());

		printf("\n");
	}
}