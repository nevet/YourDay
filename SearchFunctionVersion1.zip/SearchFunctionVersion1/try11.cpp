# include <stdio.h>
# include <vector>
# include <sstream>
# include <stdlib.h>
# include <string.h>
# include <string>
# include <ctype.h>
# include <algorithm>
# include <iostream>

using namespace std;

class matchInfo
{
public:
	int ams, bms, match, change, dis, index;

	matchInfo()
	{
		ams = bms = match = change = dis = index = 0;
	}
};

typedef pair<int, int> ii;

int tot, weight;
vector<string> list[500];
int score[500];
int f[500][500], g[500][500];

void calInfo(int i, int j, string a, string b, string & x, string & y, matchInfo & t)
{	
	if (i == 0)
	{
		t.bms += g[0][j];

		while (g[0][j])
		{
			x = " " + x;
			y = b[g[0][j] - 1] + y;

			g[0][j]--;
		}

		return;
	} else
	if (j == 0)
	{
		t.ams += g[i][0];

		while (g[i][0])
		{
			x = a[g[i][0] - 1] + x;
			y = " " + y;

			g[i][0]--;
		}

		return;
	}

	switch (g[i][j])
	{
		case 0:
			//f[i-1][j]
			x = a[i - 1] + x;
			y = " " + y;
			t.ams++;

			calInfo(i - 1, j, a, b, x, y, t);

			break;
		
		case 1:
			//f[i][j-1]
			x = " " + x;
			y = b[j - 1] + y;
			t.bms++;
			
			calInfo(i, j - 1, a, b, x, y, t);
			
			break;
		
		case 2:
			//not same
			x = a[i - 1] + x;
			y = a[i - 1] + y;
			t.change++;

			calInfo(i - 1, j - 1, a, b, x, y, t);

			break;

		case 3:
			// same
			x = a[i - 1] + x;
			y = b[j - 1] + y;
			t.match++;

			calInfo(i - 1, j - 1, a, b, x, y, t);

			break;
	}
}

int notsame(char a, char b)
{
	if (tolower(a) == tolower(b)) return 0;

	return 1;
}

void edit(string a, string b, matchInfo & ans)
{
	matchInfo temp;

	int lena = a.length();
	int lenb = b.length();

	memset(f, 0, sizeof(f));
	memset(g, 0, sizeof(g));

	for (int i = 1; i <= lena; i++)
	{
		f[i][0] = i;
		g[i][0] = i;
	}

	for (int i = 1; i <= lenb; i++)
	{
		f[0][i] = i;
		g[0][i] = i;
	}

	for (int i = 1; i <= lena; i++)
		for (int j = 1; j <= lenb; j++)
		{
			f[i][j] = f[i - 1][j] + 1;
			g[i][j] = 0;

			if (f[i][j - 1] + 1 < f[i][j])
			{
				f[i][j] = f[i][j - 1] + 1;
				g[i][j] = 1;
			}

			if (f[i - 1][j - 1] + notsame(a[i - 1], b[j - 1]) < f[i][j])
			{
				f[i][j] = f[i - 1][j - 1] + notsame(a[i - 1], b[j - 1]);
				if (notsame(a[i -1], b[j - 1]))
				{
					g[i][j] = 2;
				} else
				{
					g[i][j] = 3;
				}
			}
		}

	ans.dis = f[lena][lenb];

	string newa = "";
	string newb = "";

	calInfo(lena, lenb, a, b, newa, newb, ans);
}

bool cmp(matchInfo a, matchInfo b)
{
	if (a.match > b.match) return true; else
	if (a.match < b.match) return false; else
	if (a.ams < b.ams) return true; else
	if (a.ams > b.ams) return false; else
	if (a.change < b.change) return true; else
	if (a.change > b.change) return false;

	return false;
}

matchInfo compare(matchInfo a, matchInfo b)
{
	if (cmp(a, b))
	{
		return a;
	} else
	{
		return b;
	}
}
int sqr(int x)
{
	return x * x;
}

int calWeight(int i, int tot)
{
	return sqr(tot - i);
}

int main()
{
	freopen("lists.txt", "r", stdin);

		tot = 0;

	string line;

	while (getline(cin, line, '\n'))
	{
		stringstream sin(line);
		string s;

		while (sin>>s)
		{
			list[tot].push_back(s);
		}

		tot++;
	}

	int key = --tot;

	printf("Searching for : ");

	for (int i = 0; i < (int)list[key].size(); i++)
	{
		printf("%s ", list[key][i].c_str());
	}

	for (int i = 0; i < (int)list[key].size(); i++)
	{
		string curKey = list[key][i];
		vector<matchInfo> best;

		int weight = calWeight(i, list[key].size());

		for (int j = 0; j < tot; j++)
		{
			matchInfo temp;

			temp.dis = -1;
			
			for (int k = 0; k < (int)list[j].size(); k++)
			{
				string curP = list[j][k];
				
				matchInfo curM;

				edit(curKey, curP, curM);

				if (temp.dis == -1)
				{
					temp = curM;
				} else
				{
					temp = compare(temp, curM);
				}
			}
			
			temp.index = j;
			best.push_back(temp);
		}

		sort(best.begin(), best.end(), cmp);
		
		int p = 0;
		int q = 1;

		while (p < best.size())
		{
			while (q < best.size() && !cmp(best[q - 1], best[q])) q++;

			for (int rank = best.size() - p; p < q; p++)
			{
				score[best[p].index] += rank * weight;
			}

			q++;
		}
	}

	vector<ii> v;

	for (int i = 0; i < tot; i++)
	{
		v.push_back(ii(score[i], i));
	}

	sort(v.rbegin(), v.rend());

	printf("\n");

	for (int i = 0; i < tot; i++)
	{
		int curRecord = v[i].second;

		printf("%d.\tscore = %d\t", i + 1, score[curRecord]);
		
		for (int j = 0; j < (int)list[curRecord].size(); j++)
			printf("%s ", list[curRecord][j].c_str());

		printf("\n");
	}
}