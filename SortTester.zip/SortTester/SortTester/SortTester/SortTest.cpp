#include<iostream>
#include<algorithm>
#include<string>
#include<vector>
#include<cassert>
#include<sstream>

using namespace std;

const int INDEX_BLOCK_LOCATION			= 1;  
const int DESCRIPTION_BLOCK_LOCATION	= 2;
const int LOCATION_BLOCK_LOCATION		= 3;
const int TIME_BLOCK_LOCATION			= 4;
const int DATE_BLOCK_LOCATION			= 5;
const int PRIORITY_BLOCK_LOCATION		= 6;

int findBlockIndex(string details, int blockLocation);
string extractField(string details, int startLocation);

int extractIndex(string details);
string extractDescription(string details);
string extractLocation(string details);
string extractTime(string details);
string extractDate(string details);
int extractPriority(string details);


//@author A0088455R
const int MONTH[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

const int PERFECT_MATCH = 3;
const int MEDIOCORE_MATCH = 1;

	vector<string>* _calendarEntryList;
	vector<string>* _generalEntryList;
	vector<string>* _matchedEntryList;

	vector<string> _undoGeneralEntryList;
	vector<string> _undoCalendarEntryList;
	vector<string> _undoMatchedEntryList;
	
	vector<string> _combinedEntryList;

	string _details;

bool isLeap(int year)
{
	bool flag = false;
	
	if (year % 100 == 0)
	{
		if (year % 400 == 0)
		{
			flag = true;
		}
	} else
	{
		if (year % 4 == 0)
		{
			flag = true;
		}
	}

	return flag;
}

bool isDate(string date)
{
	int year, month, day;

	return sscanf(date.c_str(), "%d/%d/%d", &day, &month, &year) == 3;
}

bool isTime(string time)
{
	int hour, minute;

	return sscanf(time.c_str(), "%d:%d", &hour, &minute) == 2;
}


bool isLogicDate(string date)
{
	assert(date!="");
	int year, month, day;

	bool flag = true;

	//extract year, month and day from the string
	sscanf(date.c_str(), "%d/%d/%d", &day, &month, &year);
	if (year > 9999 || year < 1000)
	{
		flag = false;
	} else
	if (month > 12 || month < 1)
	{
		flag = false;
	} else
	if (day < 1)
	{
		flag = false;
	} else
	{
		if (!isLeap(year))
		{
			if (day > MONTH[month - 1])
			{
				flag = false;
			}
		} else
		if (month == 2 && day > 29)
		{
			flag = false;
		}
	}

	return flag;
}

bool isLogicTime(string time)
{
	assert(time!="");
	int hour, minute;

	bool flag = true;

	sscanf(time.c_str(), "%d:%d", &hour, &minute);

	if (hour > 23 || hour < 0)
	{
		flag = false;
	} else
	if (minute > 59 || minute < 0)
	{
		flag = false;
	}

	return flag;
}
//@author A0088455R
int extractDay(string date)
{
	int year, month, day;
	sscanf(date.c_str(), "%d/%d/%d", &day, &month, &year);
	return day;
}

int extractMonth(string date)
{
	int year, month, day;
	sscanf(date.c_str(), "%d/%d/%d", &day, &month, &year);
	return month;
}

int extractYear(string date)
{
	int year, month, day;
	sscanf(date.c_str(), "%d/%d/%d", &day, &month, &year);
	return year;
}

int extractHour(string time)
{
	int hour, minute;
	sscanf(time.c_str(), "%d:%d", &hour, &minute);
	return hour;
}



int extractMinute(string time)
{
	int hour, minute;
	sscanf(time.c_str(), "%d:%d", &hour, &minute);
	return minute;
}


void splitStartEndTime(string* start, string* end, string timeRange)
{
	*start=timeRange.substr(0,5);
	*end=timeRange.substr(6,5);
}

void swap(string &entry1, string &entry2);
int partition(vector<string> entryList, int i, int j);
void quickSort(vector<string> entryList, int low, int high);




void _initCalendar()
{
	string details;
	ostringstream convert_day;
	ostringstream convert_month;
	ostringstream convert_hour;
	cout<<"This is executed"<<endl;
	for (int i = 28; i > 9; i--)
	 {
		 for (int j=12; j>9; j--)
		 {
			 for (int k=15; k>9; k--) 
			 {
				 convert_day<<i;
				 convert_month<<j;
				 convert_hour<<k;
				 details = "##Meeting CS2103#UTown#"+convert_hour.str()+":00-23:59#"+convert_day.str()+"/"+convert_month.str()+"/2012#high#";
				_calendarEntryList->push_back(details);
				 convert_day.str("");
				 convert_month.str("");
				 convert_hour.str("");
				  convert_day.clear();
				 convert_month.clear();
				 convert_hour.clear();
				//cout<<_calendarEntryList->size()<<endl;
			 }
		}
	}
}

bool isEarlierTime(string &entry1, string &entry2);
bool isEarlierYear(string &entry1, string &entry2);
bool isEarlierMonth(string &entry1, string &entry2);
bool isEarlierDay(string &entry1, string &entry2);
bool isEarlier(string &entry1, string &entry2);

int main()
{
	vector<string> general;
	vector<string> calendar;
	_generalEntryList=&general;
	_calendarEntryList=&calendar;
	_initCalendar();
	int listSize=calendar.size();
	for (int i = 0; i<listSize; i++)
		cout<< calendar[i]<<endl;
	//sort(calendar.begin(),calendar.end(),isEarlierTime);
	//sort(calendar.begin(),calendar.end(),isEarlierYear);
	//sort(calendar.begin(),calendar.end(),isEarlierMonth);
	//sort(calendar.begin(),calendar.end(),isEarlier);
	quickSort(calendar,0,listSize-1);
	for (int i = 0; i<listSize; i++)
		cout<< calendar[i]<<endl;
	return 0;
}

bool isEarlier(string &entry1, string &entry2)
{
	string timeRange1;
	string timeRange2;
	timeRange1=extractTime(entry1);
	timeRange2=extractTime(entry2);
	string entryDate1;
	string entryDate2;
	entryDate1=extractDate(entry1);
	entryDate2=extractDate(entry2);
	int entryDay1 = extractDay(entryDate1);
	int entryMonth1 = extractMonth(entryDate1);
	int entryYear1 = extractYear(entryDate2);
	int entryDay2 = extractDay(entryDate2);
	int entryMonth2 = extractMonth(entryDate2);
	int entryYear2 = extractYear(entryDate2);
	ostringstream os1;
	ostringstream os2;
	os1<<entryYear1<<entryMonth1<<entryDay1<<timeRange1;
	os2<<entryYear2<<entryMonth2<<entryDay2<<timeRange2;
	return os1.str() < os2.str();
}


void swap(string &entry1, string &entry2)
{
	string temp;
	temp = entry1;
	entry1 = entry2;
	entry2 = temp;
}
int partition(vector<string> entryList, int low, int high)
{
	if (low == high) return low;
	int index = low;
	string pivot = entryList[index];
	
	int m = low+1;
	for ( int k = low; k <= high; k++ )
	{
		if ( isEarlier(pivot, entryList[k]))
		{		
			m++;
			swap(entryList[k], entryList[high]);
			if (entryList[m]==pivot)
				index=m;
		}
    }

  swap(entryList[index], entryList[m]);  	
  return m;
}
void quickSort(vector<string> entryList, int low, int high)
{
	int pivotIndex;
	if (low>=high)
	{
		return;
	}
	else if (low < high)
	{
		pivotIndex = partition (entryList,low,high);
		quickSort(entryList,low,pivotIndex-1);
		quickSort(entryList,pivotIndex+1,high);
	}
}

int findBlockIndex(string details, int blockLocation)
{
	int blockCounter = 0;
	int index;
	for (index = 0; index<details.size(); index++)
	{
		if (details[index] == '#')
		{
			blockCounter++;
		}
		if (blockCounter == blockLocation)
		{
			break;
		}
	}
	return index;
}
string extractField(string details, int startLocation)
{
	int index = startLocation;
	string extracted = "";
	while (details[++index] != '#')
	{
		extracted+=details[index];
	}
	return extracted;
}

int extractIndex(string details)
{
	string tempIndex = "";
	int index;
	int indexLocation;
	indexLocation = findBlockIndex(details, INDEX_BLOCK_LOCATION);
	tempIndex = extractField(details, indexLocation);
	index = atoi(tempIndex.c_str());
	return index;
}

string extractDescription(string details)
{
	string tempDescription="";
	int indexLocation;
	indexLocation = findBlockIndex(details, DESCRIPTION_BLOCK_LOCATION);
	tempDescription = extractField(details, indexLocation);
	return tempDescription;
}

string extractLocation(string details)
{
	string tempLocation="";
	int indexLocation;
	indexLocation = findBlockIndex(details, LOCATION_BLOCK_LOCATION);
	tempLocation = extractField(details, indexLocation);
	return tempLocation;
}

string extractTime(string details)
{
	string tempTime="";
	int indexLocation;
	indexLocation = findBlockIndex(details, TIME_BLOCK_LOCATION);
	tempTime = extractField(details, indexLocation);
	return tempTime;
}
string extractDate(string details)
{
	string tempDate="";
	int indexLocation;
	indexLocation = findBlockIndex(details, DATE_BLOCK_LOCATION);
	tempDate = extractField(details, indexLocation);
	return tempDate;
}

int extractPriority(string details)
{
	string tempPriority="";
	int priority;
	int indexLocation;
	indexLocation = findBlockIndex(details, PRIORITY_BLOCK_LOCATION);
	tempPriority = extractField(details, indexLocation);
	priority= atoi(tempPriority.c_str());
	return priority;
}

