# include <stdio.h>

int a[400];
int n;

void swap(int & a, int & b)
{
	int t;

	t = a;
	a = b;
	b = t;
}

void sort(int l, int r)
{
	int t, i, j;

	if (l >= r) return;

	i = l; j = r;
	t = a[(l + r) >> 1];

	while (i <= j)
	{
		while (a[i] < t) i ++;
		while (a[j] > t) j --;

		if (i <= j)
		{
			swap(a[i], a[j]);
			i ++;
			j --;
		}
	}

	sort(l, j);
	sort(i, r);
}

int main()
{
	scanf("%d", &n);
	for (int i = 0; i < n; i++) scanf("%d", &a[i]);

	sort(0, n - 1);

	for (int i = 0; i < n; i++)
		printf("%d ", a[i]);
}